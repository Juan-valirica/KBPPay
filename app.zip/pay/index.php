<?php
require __DIR__ . "/config/database.php";
echo "✅ KBPPAY conectado a la base de datos";
